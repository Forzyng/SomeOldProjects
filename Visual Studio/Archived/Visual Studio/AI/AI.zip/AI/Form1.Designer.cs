﻿namespace AI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxPeople = new System.Windows.Forms.CheckBox();
            this.rGreen = new System.Windows.Forms.RadioButton();
            this.rYellow = new System.Windows.Forms.RadioButton();
            this.rRed = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxPeople = new System.Windows.Forms.TextBox();
            this.wGreen = new System.Windows.Forms.TextBox();
            this.wYellow = new System.Windows.Forms.TextBox();
            this.wRed = new System.Windows.Forms.TextBox();
            this.textResult = new System.Windows.Forms.TextBox();
            this.btnCalcSum = new System.Windows.Forms.Button();
            this.btnEduRed = new System.Windows.Forms.Button();
            this.btnEduAll = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxPeople);
            this.groupBox1.Controls.Add(this.rGreen);
            this.groupBox1.Controls.Add(this.rYellow);
            this.groupBox1.Controls.Add(this.rRed);
            this.groupBox1.Location = new System.Drawing.Point(38, 50);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(132, 151);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Цвет светофора";
            // 
            // checkBoxPeople
            // 
            this.checkBoxPeople.AutoSize = true;
            this.checkBoxPeople.Location = new System.Drawing.Point(14, 112);
            this.checkBoxPeople.Name = "checkBoxPeople";
            this.checkBoxPeople.Size = new System.Drawing.Size(62, 19);
            this.checkBoxPeople.TabIndex = 3;
            this.checkBoxPeople.Text = "People";
            this.checkBoxPeople.UseVisualStyleBackColor = true;
            this.checkBoxPeople.CheckedChanged += new System.EventHandler(this.checkBoxPeople_CheckedChanged);
            // 
            // rGreen
            // 
            this.rGreen.AutoSize = true;
            this.rGreen.Location = new System.Drawing.Point(15, 72);
            this.rGreen.Name = "rGreen";
            this.rGreen.Size = new System.Drawing.Size(74, 19);
            this.rGreen.TabIndex = 2;
            this.rGreen.TabStop = true;
            this.rGreen.Text = "Зеленый";
            this.rGreen.UseVisualStyleBackColor = true;
            this.rGreen.CheckedChanged += new System.EventHandler(this.changeLed);
            // 
            // rYellow
            // 
            this.rYellow.AutoSize = true;
            this.rYellow.Location = new System.Drawing.Point(15, 52);
            this.rYellow.Name = "rYellow";
            this.rYellow.Size = new System.Drawing.Size(70, 19);
            this.rYellow.TabIndex = 1;
            this.rYellow.TabStop = true;
            this.rYellow.Text = "Желтый";
            this.rYellow.UseVisualStyleBackColor = true;
            this.rYellow.CheckedChanged += new System.EventHandler(this.changeLed);
            // 
            // rRed
            // 
            this.rRed.AutoSize = true;
            this.rRed.Location = new System.Drawing.Point(15, 31);
            this.rRed.Name = "rRed";
            this.rRed.Size = new System.Drawing.Size(74, 19);
            this.rRed.TabIndex = 0;
            this.rRed.TabStop = true;
            this.rRed.Text = "Красный";
            this.rRed.UseVisualStyleBackColor = true;
            this.rRed.CheckedChanged += new System.EventHandler(this.changeLed);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBoxPeople);
            this.groupBox2.Controls.Add(this.wGreen);
            this.groupBox2.Controls.Add(this.wYellow);
            this.groupBox2.Controls.Add(this.wRed);
            this.groupBox2.Location = new System.Drawing.Point(197, 50);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(169, 151);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Веса";
            // 
            // textBoxPeople
            // 
            this.textBoxPeople.Location = new System.Drawing.Point(14, 112);
            this.textBoxPeople.Name = "textBoxPeople";
            this.textBoxPeople.Size = new System.Drawing.Size(100, 23);
            this.textBoxPeople.TabIndex = 3;
            // 
            // wGreen
            // 
            this.wGreen.Location = new System.Drawing.Point(13, 72);
            this.wGreen.Name = "wGreen";
            this.wGreen.Size = new System.Drawing.Size(100, 23);
            this.wGreen.TabIndex = 2;
            // 
            // wYellow
            // 
            this.wYellow.Location = new System.Drawing.Point(13, 52);
            this.wYellow.Name = "wYellow";
            this.wYellow.Size = new System.Drawing.Size(100, 23);
            this.wYellow.TabIndex = 1;
            // 
            // wRed
            // 
            this.wRed.Location = new System.Drawing.Point(13, 30);
            this.wRed.Name = "wRed";
            this.wRed.Size = new System.Drawing.Size(100, 23);
            this.wRed.TabIndex = 0;
            // 
            // textResult
            // 
            this.textResult.Location = new System.Drawing.Point(403, 90);
            this.textResult.Name = "textResult";
            this.textResult.Size = new System.Drawing.Size(100, 23);
            this.textResult.TabIndex = 2;
            // 
            // btnCalcSum
            // 
            this.btnCalcSum.Location = new System.Drawing.Point(417, 173);
            this.btnCalcSum.Name = "btnCalcSum";
            this.btnCalcSum.Size = new System.Drawing.Size(75, 23);
            this.btnCalcSum.TabIndex = 3;
            this.btnCalcSum.Text = "Calc Sum";
            this.btnCalcSum.UseVisualStyleBackColor = true;
            this.btnCalcSum.Click += new System.EventHandler(this.btnCalcSum_Click);
            // 
            // btnEduRed
            // 
            this.btnEduRed.Location = new System.Drawing.Point(77, 330);
            this.btnEduRed.Name = "btnEduRed";
            this.btnEduRed.Size = new System.Drawing.Size(75, 23);
            this.btnEduRed.TabIndex = 4;
            this.btnEduRed.Text = "Edu Red";
            this.btnEduRed.UseVisualStyleBackColor = true;
            this.btnEduRed.Click += new System.EventHandler(this.btnEduRed_Click);
            // 
            // btnEduAll
            // 
            this.btnEduAll.Location = new System.Drawing.Point(236, 332);
            this.btnEduAll.Name = "btnEduAll";
            this.btnEduAll.Size = new System.Drawing.Size(75, 23);
            this.btnEduAll.TabIndex = 5;
            this.btnEduAll.Text = "Edu All";
            this.btnEduAll.UseVisualStyleBackColor = true;
            this.btnEduAll.Click += new System.EventHandler(this.btnEduAll_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(354, 329);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnEduAll);
            this.Controls.Add(this.btnEduRed);
            this.Controls.Add(this.btnCalcSum);
            this.Controls.Add(this.textResult);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton rGreen;
        private RadioButton rYellow;
        private RadioButton rRed;
        private GroupBox groupBox2;
        public TextBox wGreen;
        public TextBox wYellow;
        public TextBox wRed;
        private Button btnCalcSum;
        public TextBox textResult;
        private Button btnEduRed;
        private Button btnEduAll;
        private CheckBox checkBoxPeople;
        public TextBox textBoxPeople;
        private Button button1;
    }
}