﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace CSLanHttpTest
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(edAddress.Text))
            {
                MessageBox.Show("Введите адрес");
                edAddress.Focus();
                return;
            }

            try
            {
                HttpWebRequest request;
                HttpWebResponse response;

                request = WebRequest.CreateHttp(edAddress.Text);
                //request.Credentials = new NetworkCredential("user", "password");
                request.CookieContainer = new CookieContainer();                
                // request.CookieContainer.Add(new Cookie("lastConnectionDate", "08.09.2021"));

                response = (HttpWebResponse)request.GetResponse();
                if (lbHeaders.Items.Count > 0)
                    lbHeaders.Items.Clear();

                foreach (string h in response.Headers)
                {
                    lbHeaders.Items.Add($"{h}: {response.Headers[h]}");
                }
                lbHeaders.Items.Add("");
                lbHeaders.Items.Add("**********************************************");
                lbHeaders.Items.Add("Cookie");
                lbHeaders.Items.Add("**********************************************");
                foreach (Cookie c in response.Cookies)
                {
                    lbHeaders.Items.Add($"{c.Name}: {c.Value}");
                }

                StreamReader reader = new StreamReader(response.GetResponseStream());
                //Stream stream = response.GetResponseStream();
                edResponse.Text = reader.ReadToEnd();
                reader.Close();
                response.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
