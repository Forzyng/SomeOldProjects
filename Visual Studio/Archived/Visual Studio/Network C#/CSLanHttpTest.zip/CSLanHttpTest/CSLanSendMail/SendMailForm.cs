﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;

namespace CSLanSendMail
{
    public partial class SendMailForm : Form
    {
        public SendMailForm()
        {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            MailMessage message = new MailMessage(edFrom.Text, edTo.Text);
            message.Subject = edTheme.Text;
            message.IsBodyHtml = false;
            message.Body = edMessage.Text;

            if (!string.IsNullOrWhiteSpace(edAttachment.Text))
            {
                Attachment attachment = new Attachment(edAttachment.Text); // - файл для отправки
                message.Attachments.Add(attachment);
            }

            SmtpClient smtp = new SmtpClient(edServer.Text, (int)edPort.Value);
            smtp.EnableSsl = cbUseSSL.Checked;
            smtp.Credentials = new NetworkCredential(edFrom.Text, edPassword.Text);

            Action a = () =>
            {
                try
                {
                    MessageBox.Show("Отправка сообщения");
                    smtp.SendCompleted += Smtp_SendCompleted;
                    smtp.Send(message);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            };
            Task.Factory.StartNew(a);
        }

        private void Smtp_SendCompleted(object sender, AsyncCompletedEventArgs e)
        {
            if (e.Error!=null)
                MessageBox.Show("Ошибка при отправке: " + e.Error.Message);
            else
                MessageBox.Show("Отправка завершена");
        }

        private void btnAttachment_Click(object sender, EventArgs e)
        {
            if (dlgOpen.ShowDialog() != DialogResult.OK)
            {
                edAttachment.Text = "";
                return;
            }

            edAttachment.Text = dlgOpen.FileName;
        }
    }
}
