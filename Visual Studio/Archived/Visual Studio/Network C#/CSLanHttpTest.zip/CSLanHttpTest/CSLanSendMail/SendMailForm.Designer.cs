﻿
namespace CSLanSendMail
{
    partial class SendMailForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.edFrom = new System.Windows.Forms.TextBox();
            this.edTo = new System.Windows.Forms.TextBox();
            this.edTheme = new System.Windows.Forms.TextBox();
            this.edPassword = new System.Windows.Forms.TextBox();
            this.edMessage = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnSend = new System.Windows.Forms.Button();
            this.cbUseSSL = new System.Windows.Forms.CheckBox();
            this.edServer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.edPort = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.edAttachment = new System.Windows.Forms.TextBox();
            this.dlgOpen = new System.Windows.Forms.OpenFileDialog();
            this.btnAttachment = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.edPort)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "From";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "To";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Theme";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Password";
            // 
            // edFrom
            // 
            this.edFrom.Location = new System.Drawing.Point(66, 66);
            this.edFrom.Name = "edFrom";
            this.edFrom.Size = new System.Drawing.Size(285, 20);
            this.edFrom.TabIndex = 2;
            // 
            // edTo
            // 
            this.edTo.Location = new System.Drawing.Point(66, 93);
            this.edTo.Name = "edTo";
            this.edTo.Size = new System.Drawing.Size(285, 20);
            this.edTo.TabIndex = 3;
            // 
            // edTheme
            // 
            this.edTheme.Location = new System.Drawing.Point(66, 120);
            this.edTheme.Name = "edTheme";
            this.edTheme.Size = new System.Drawing.Size(285, 20);
            this.edTheme.TabIndex = 4;
            // 
            // edPassword
            // 
            this.edPassword.Location = new System.Drawing.Point(66, 147);
            this.edPassword.Name = "edPassword";
            this.edPassword.PasswordChar = '*';
            this.edPassword.Size = new System.Drawing.Size(285, 20);
            this.edPassword.TabIndex = 5;
            // 
            // edMessage
            // 
            this.edMessage.Location = new System.Drawing.Point(15, 210);
            this.edMessage.Multiline = true;
            this.edMessage.Name = "edMessage";
            this.edMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.edMessage.Size = new System.Drawing.Size(497, 149);
            this.edMessage.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Message";
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(357, 10);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(145, 23);
            this.btnSend.TabIndex = 8;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // cbUseSSL
            // 
            this.cbUseSSL.AutoSize = true;
            this.cbUseSSL.Checked = true;
            this.cbUseSSL.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbUseSSL.Location = new System.Drawing.Point(66, 174);
            this.cbUseSSL.Name = "cbUseSSL";
            this.cbUseSSL.Size = new System.Drawing.Size(46, 17);
            this.cbUseSSL.TabIndex = 6;
            this.cbUseSSL.Text = "SSL";
            this.cbUseSSL.UseVisualStyleBackColor = true;
            // 
            // edServer
            // 
            this.edServer.Location = new System.Drawing.Point(66, 12);
            this.edServer.Name = "edServer";
            this.edServer.Size = new System.Drawing.Size(285, 20);
            this.edServer.TabIndex = 0;
            this.edServer.Text = "smtp.gmail.com";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Server";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Port";
            // 
            // edPort
            // 
            this.edPort.Location = new System.Drawing.Point(66, 38);
            this.edPort.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.edPort.Name = "edPort";
            this.edPort.Size = new System.Drawing.Size(120, 20);
            this.edPort.TabIndex = 1;
            this.edPort.Value = new decimal(new int[] {
            587,
            0,
            0,
            0});
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 369);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Attachment";
            // 
            // edAttachment
            // 
            this.edAttachment.Location = new System.Drawing.Point(90, 366);
            this.edAttachment.Name = "edAttachment";
            this.edAttachment.ReadOnly = true;
            this.edAttachment.Size = new System.Drawing.Size(294, 20);
            this.edAttachment.TabIndex = 16;
            // 
            // btnAttachment
            // 
            this.btnAttachment.Location = new System.Drawing.Point(391, 364);
            this.btnAttachment.Name = "btnAttachment";
            this.btnAttachment.Size = new System.Drawing.Size(111, 23);
            this.btnAttachment.TabIndex = 17;
            this.btnAttachment.Text = "Select file...";
            this.btnAttachment.UseVisualStyleBackColor = true;
            this.btnAttachment.Click += new System.EventHandler(this.btnAttachment_Click);
            // 
            // SendMailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 402);
            this.Controls.Add(this.btnAttachment);
            this.Controls.Add(this.edAttachment);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.edPort);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.edServer);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbUseSSL);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.edMessage);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.edPassword);
            this.Controls.Add(this.edTheme);
            this.Controls.Add(this.edTo);
            this.Controls.Add(this.edFrom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "SendMailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SendMail";
            ((System.ComponentModel.ISupportInitialize)(this.edPort)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox edFrom;
        private System.Windows.Forms.TextBox edTo;
        private System.Windows.Forms.TextBox edTheme;
        private System.Windows.Forms.TextBox edPassword;
        private System.Windows.Forms.TextBox edMessage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.CheckBox cbUseSSL;
        private System.Windows.Forms.TextBox edServer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown edPort;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox edAttachment;
        private System.Windows.Forms.OpenFileDialog dlgOpen;
        private System.Windows.Forms.Button btnAttachment;
    }
}

