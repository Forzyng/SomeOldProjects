﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdoNetDapperTest
{
    public partial class MainForm : Form
    {
        private BookSalesDb db;
        private const string connectionStr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\dovgoluckiy\Documents\TestDb.mdf;Integrated Security=True;Connect Timeout=30";
        public MainForm()
        {
            InitializeComponent();

            dgvCountries.MultiSelect = false;
            dgvCountries.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvCountries.ReadOnly = true;

            dgvAuthors.MultiSelect = false;
            dgvAuthors.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvAuthors.ReadOnly = true;

            db = new BookSalesDb(connectionStr);

            dgvCountries.DataSource = db.Countries;
            dgvAuthors.DataSource = db.Authors;
        }
    }
}
